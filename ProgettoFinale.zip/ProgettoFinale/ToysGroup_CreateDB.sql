-- Crea il database ToysGroup
CREATE DATABASE ToysGroup;

-- Seleziona il database ToysGroup
USE ToysGroup;

-- Creazione della tabella Category
CREATE TABLE Category (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255)
);

-- Creazione della tabella Product
CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255),
    Description TEXT,
    CategoryID INT,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

-- Creazione della tabella Region
CREATE TABLE Region (
    RegionID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255)
);

-- Creazione della tabella Country
CREATE TABLE Country (
    CountryID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(255),
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Creazione della tabella Sales
CREATE TABLE Sales (
    SalesID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SaleDate DATE,
    Amount DECIMAL(10,2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);



-- Popolare la tabella Category con dati di esempio
INSERT INTO Category (Name) VALUES
    ('Action Figures'),
    ('Dolls'),
    ('Board Games'),
    ('Puzzle Games'),
    ('Building Blocks'),
    ('Outdoor Toys');

-- Popolare la tabella Product con dati di esempio
INSERT INTO Product (Name, Description, CategoryID) VALUES
    ('Superman Action Figure', 'Action figure of Superman with cape', 1),
    ('Barbie Doll', 'Fashion Barbie doll with accessories', 2),
    ('Monopoly', 'Classic board game of buying and trading properties', 3),
    ('Rubik''s Cube', '3D combination puzzle', 4),
    ('LEGO Classic Bricks', 'Assorted LEGO bricks for building', 5),
    ('Frisbee', 'Plastic flying disc for outdoor play', 6),
    ('Chess Set', 'Traditional chess set with wooden pieces', 3),
    ('Jigsaw Puzzle', '1000-piece jigsaw puzzle of a scenic landscape', 4),
    ('Nerf Blaster', 'Foam dart blaster for fun battles', 1),
    ('Remote Control Car', 'Miniature remote control car for racing', 6);
    
-- Popolare la tabella Region con dati di esempio
INSERT INTO Region (Name) VALUES
    ('North America'),
    ('Europe'),
    ('Asia');

-- Popolare la tabella Country con dati di esempio
INSERT INTO Country (Name, RegionID) VALUES
    ('United States', 1),
    ('Canada', 1),
    ('United Kingdom', 2),
    ('Germany', 2),
    ('France', 2),
    ('Italy', 2),
    ('China', 3),
    ('Japan', 3),
    ('India', 3);

-- Popolare la tabella Sales con dati di esempio
INSERT INTO Sales (ProductID, RegionID, SaleDate, Amount) VALUES
    (1, 1, '2022-01-05', 19.99),
    (2, 2, '2023-05-10', 29.99),
    (3, 1, '2023-07-15', 39.99),
    (4, 3, '2024-02-20', 9.99),
    (1, 2, '2022-04-12', 24.99),
    (3, 3, '2023-11-30', 34.99),
    (2, 1, '2024-06-25', 29.99),
    (4, 2, '2022-08-18', 14.99),
    (1, 3, '2023-10-05', 19.99),
    (2, 3, '2024-09-15', 29.99),
    (3, 2, '2022-12-20', 39.99),
    (4, 1, '2023-03-08', 9.99),
    (1, 2, '2024-02-14', 24.99),
    (3, 1, '2022-07-21', 34.99),
    (2, 3, '2023-09-03', 29.99),
    (4, 2, '2024-11-28', 14.99),
    (1, 1, '2022-04-30', 19.99),
    (2, 2, '2023-08-12', 29.99),
    (3, 3, '2024-05-17', 39.99),
    (4, 1, '2022-11-25', 9.99),
    (1, 3, '2023-01-09', 24.99),
    (3, 2, '2024-03-22', 34.99),
    (2, 1, '2022-06-14', 29.99),
    (4, 3, '2023-09-01', 14.99),
    (1, 2, '2024-10-11', 19.99),
    (2, 3, '2022-03-27', 29.99),
    (3, 1, '2023-08-04', 39.99),
    (4, 2, '2024-01-19', 9.99);


