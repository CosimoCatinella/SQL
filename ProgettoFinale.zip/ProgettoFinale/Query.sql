USE ToysGroup;

-- 1) Verificare che i campi definiti come PK siano univoci. 
/* 
	Per soddisfare questa richiesta ho pensato a un confronto tra 
    il conteggio delle righe e il conteggio dei valori univoci facendo si che in output abbiamo due opzioni
    1. output = a 1 se la condizione è vera (univoci)
    2. outpu = a 0 se la condizione è falsa (non univoci)
*/


--  Verifica unicità dei campi chiave primarie nella tabella Category
SELECT COUNT(*) = COUNT(DISTINCT CategoryID) AS ControlloCategory
FROM Category;

-- Verifica unicità dei campi chiave primarie nella tabella Product
SELECT COUNT(*) = COUNT(DISTINCT ProductID) AS ControlloProduct
FROM Product;

-- Verifica unicità dei campi chiave primarie nella tabella Region
SELECT COUNT(*) = COUNT(DISTINCT RegionID) AS ControlloRegion
FROM Region;

-- Verifica unicità dei campi chiave primarie nella tabella Country
SELECT COUNT(*) = COUNT(DISTINCT CountryID) AS ControlloCountry
FROM Country;

-- Verifica unicità dei campi chiave primarie nella tabella Sales
SELECT COUNT(*) = COUNT(DISTINCT SalesID) AS ControlloSales
FROM Sales;


-- 2) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

SELECT p.Name AS ProductName, YEAR(s.SaleDate) AS Year, SUM(s.Amount) AS TotalRevenue
FROM Product p
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, YEAR
ORDER BY p.ProductID, YEAR DESC;

-- 3) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. 

SELECT r.Name AS State, YEAR(s.SaleDate) AS Year, SUM(s.Amount) AS TotalRevenue
FROM Region r
JOIN Sales s ON r.RegionID = s.RegionID
GROUP BY r.Name, YEAR 
ORDER BY YEAR ASC, TotalRevenue DESC;


-- 4) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

SELECT c.Name AS Category, SUM(s.Amount) AS TotalRevenue
FROM Category c
JOIN Product p ON c.CategoryID = p.CategoryID
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY c.Name
ORDER BY TotalRevenue DESC
LIMIT 1;

-- 5) Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. 
	
    -- 1) Utilizzo di una Left Join
    
SELECT p.Name AS Name
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.ProductID IS NULL;

	-- 2) Utilizzo di Sottoquery
SELECT p.Name AS Name
FROM Product p
WHERE p.ProductID NOT IN (
	SELECT DISTINCT ProductID 
    FROM Sales
    );

-- 6) Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).
	-- Data più recente
SELECT p.Name AS Name, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, Name
ORDER BY Name;
	
    -- Data del primo acquisto in assoluto
    
SELECT p.Name AS Name, MIN(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductID, Name
ORDER BY Name;
/*
BONUS: Esporre l’elenco delle transazioni indicando nel result set il 
codice documento, 
la data, 
il nome del prodotto, 
la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più 
di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
*/

SELECT s.SalesID AS Document, s.SaleDate AS Date, p.Name AS Product, c.Name AS Category, r.Name AS Region, cy.Name AS Country,
    CASE 
        WHEN DATEDIFF(CURDATE(), s.SaleDate) > 180 THEN 'TRUE'
        ELSE 'FALSE'
    END AS Passed180Days
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON p.CategoryID = c.CategoryID
JOIN Region r ON s.RegionID = r.RegionID
JOIN Country cy ON r.RegionID = cy.RegionID
ORDER BY Document, Passed180Days;
